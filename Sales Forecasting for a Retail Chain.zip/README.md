# Retail Sales Forecasting — Complete Project

## Included
- 12,000-row CSV and Excel dataset
- Python EDA script
- Python ML/forecasting script
- Python requirements
- MySQL database and analysis queries
- Power BI dashboard guide
- Project report template
- PPT outline
- Outputs folder for generated results

## Run Python
From the `python` folder:
`pip install -r requirements.txt`
`python 01_eda.py`
`python 02_ml_forecasting.py`

The scripts generate CSV analysis files and `sales_forecast_results.csv` in `outputs`.

## SQL
Run `sql/retail_sales_analysis.sql` in MySQL Workbench and import the CSV into the `retail_sales` table using the Table Data Import Wizard.

## Power BI
Follow `powerbi/dashboard_guide.md`.

Note: the dataset is synthetic and created for academic/project demonstration.
