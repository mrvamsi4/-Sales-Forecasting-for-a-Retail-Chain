# Power BI Dashboard

Import `dataset/retail_sales_forecasting_dataset.csv`.

Create measures:
```DAX
Total Sales = SUM(RetailSales[Sales])
Total Units Sold = SUM(RetailSales[Units_Sold])
Average Sales = AVERAGE(RetailSales[Sales])
Total Stores = DISTINCTCOUNT(RetailSales[Store_ID])
```

Recommended visuals:
1. KPI cards: Total Sales, Units Sold, Average Sales, Stores
2. Line chart: Monthly Sales Trend
3. Column chart: Sales by Store
4. Bar chart: Sales by Category
5. Line chart: Actual vs Predicted Sales
6. Bar chart: Top 10 Products
7. Column/Donut chart: Promotion Analysis

Slicers: Date, Store_ID, Region, Product_Category, Promotion.

After running `python/02_ml_forecasting.py`, import `outputs/sales_forecast_results.csv` and use Date, Actual_Sales and Predicted_Sales for the forecast visual.
