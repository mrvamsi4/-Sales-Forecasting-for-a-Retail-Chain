CREATE DATABASE IF NOT EXISTS retail_sales_db;
USE retail_sales_db;
DROP TABLE IF EXISTS retail_sales;
CREATE TABLE retail_sales (
Date DATE, Store_ID VARCHAR(20), Region VARCHAR(30), Product_ID VARCHAR(20),
Product_Name VARCHAR(100), Product_Category VARCHAR(50), Units_Sold INT,
Price DECIMAL(12,2), Discount_Percent DECIMAL(5,2), Promotion VARCHAR(10),
Sales DECIMAL(15,2), Year INT, Month INT, Quarter INT, DayOfWeek VARCHAR(20), Weekend VARCHAR(10));

-- Import the CSV using MySQL Workbench Table Data Import Wizard, then run:
SELECT COUNT(*) AS Row_Count FROM retail_sales;
SELECT * FROM retail_sales LIMIT 10;
SELECT SUM(Sales) AS Total_Sales FROM retail_sales;
SELECT SUM(Units_Sold) AS Total_Units_Sold FROM retail_sales;
SELECT AVG(Sales) AS Average_Sales FROM retail_sales;

SELECT Store_ID,SUM(Sales) AS Total_Sales FROM retail_sales GROUP BY Store_ID ORDER BY Total_Sales DESC;
SELECT Region,SUM(Sales) AS Total_Sales FROM retail_sales GROUP BY Region ORDER BY Total_Sales DESC;
SELECT Product_Category,SUM(Sales) AS Total_Sales FROM retail_sales GROUP BY Product_Category ORDER BY Total_Sales DESC;
SELECT Product_ID,Product_Name,SUM(Sales) AS Total_Sales FROM retail_sales GROUP BY Product_ID,Product_Name ORDER BY Total_Sales DESC LIMIT 10;
SELECT Year,Month,SUM(Sales) AS Monthly_Sales FROM retail_sales GROUP BY Year,Month ORDER BY Year,Month;
SELECT Year,Quarter,SUM(Sales) AS Quarterly_Sales FROM retail_sales GROUP BY Year,Quarter ORDER BY Year,Quarter;
SELECT Year,SUM(Sales) AS Yearly_Sales FROM retail_sales GROUP BY Year ORDER BY Year;
SELECT Promotion,COUNT(*) AS Transactions,SUM(Units_Sold) AS Units_Sold,SUM(Sales) AS Total_Sales,AVG(Sales) AS Average_Sales FROM retail_sales GROUP BY Promotion;
SELECT Discount_Percent,SUM(Sales) AS Total_Sales,AVG(Sales) AS Average_Sales,SUM(Units_Sold) AS Units_Sold FROM retail_sales GROUP BY Discount_Percent ORDER BY Discount_Percent;
SELECT Store_ID,Product_Category,SUM(Sales) AS Total_Sales FROM retail_sales GROUP BY Store_ID,Product_Category ORDER BY Store_ID,Total_Sales DESC;
SELECT Product_Name,Sales,CASE WHEN Sales>=50000 THEN 'High' WHEN Sales>=20000 THEN 'Medium' ELSE 'Low' END AS Sales_Category FROM retail_sales;
SELECT * FROM retail_sales WHERE Sales>=100000 ORDER BY Sales DESC;
SELECT Weekend,COUNT(*) AS Transactions,SUM(Sales) AS Total_Sales,AVG(Sales) AS Average_Sales FROM retail_sales GROUP BY Weekend;
