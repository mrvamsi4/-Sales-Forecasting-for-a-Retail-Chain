import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
df=pd.read_csv(BASE/'dataset'/'retail_sales_forecasting_dataset.csv')
df['Date']=pd.to_datetime(df['Date'])
out=BASE/'outputs'; out.mkdir(exist_ok=True)

print('Shape:', df.shape)
print('Missing values:\n', df.isnull().sum())
print('Duplicates:', df.duplicated().sum())

kpis=pd.DataFrame({
 'Metric':['Total Sales','Total Units Sold','Average Sales','Highest Sale','Lowest Sale','Stores'],
 'Value':[df.Sales.sum(),df.Units_Sold.sum(),df.Sales.mean(),df.Sales.max(),df.Sales.min(),df.Store_ID.nunique()]
})
kpis.to_csv(out/'kpi_summary.csv',index=False)

monthly=df.groupby(df.Date.dt.to_period('M')).Sales.sum().reset_index()
monthly.columns=['Month','Sales']; monthly.Month=monthly.Month.dt.to_timestamp()
monthly.to_csv(out/'monthly_sales.csv',index=False)

for col,fn in [('Store_ID','store_sales.csv'),('Region','region_sales.csv'),('Product_Category','category_sales.csv')]:
    df.groupby(col).Sales.sum().sort_values(ascending=False).reset_index().to_csv(out/fn,index=False)
df.groupby('Product_Name').Sales.sum().sort_values(ascending=False).head(10).reset_index().to_csv(out/'top_10_products.csv',index=False)

plt.figure(figsize=(12,6)); plt.plot(monthly.Month,monthly.Sales); plt.title('Monthly Sales Trend'); plt.xlabel('Month'); plt.ylabel('Sales'); plt.tight_layout(); plt.savefig(out/'monthly_sales_trend.png',dpi=160); plt.close()
plt.figure(figsize=(10,6)); df.groupby('Product_Category').Sales.sum().sort_values(ascending=False).plot(kind='bar'); plt.title('Sales by Product Category'); plt.tight_layout(); plt.savefig(out/'sales_by_category.png',dpi=160); plt.close()
plt.figure(figsize=(8,5)); df.groupby('Store_ID').Sales.sum().sort_values(ascending=False).plot(kind='bar'); plt.title('Sales by Store'); plt.tight_layout(); plt.savefig(out/'sales_by_store.png',dpi=160); plt.close()
print('EDA outputs saved to',out)
