import pandas as pd, numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE=Path(__file__).resolve().parents[1]
df=pd.read_csv(BASE/'dataset'/'retail_sales_forecasting_dataset.csv')
df['Date']=pd.to_datetime(df['Date'])
out=BASE/'outputs'; out.mkdir(exist_ok=True)

features=['Units_Sold','Price','Discount_Percent','Year','Month','Quarter','Store_ID','Region','Product_Category','Promotion','Weekend']
target='Sales'
X=df[features]; y=df[target]
cat=['Store_ID','Region','Product_Category','Promotion','Weekend']
num=['Units_Sold','Price','Discount_Percent','Year','Month','Quarter']
prep=ColumnTransformer([('num','passthrough',num),('cat',OneHotEncoder(handle_unknown='ignore'),cat)])
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.20,random_state=42)

models={'Linear Regression':LinearRegression(),'Random Forest':RandomForestRegressor(n_estimators=150,random_state=42,n_jobs=-1)}
results=[]; predout=pd.DataFrame({'Date':df.loc[Xte.index,'Date'],'Actual_Sales':yte.values})

for name,model in models.items():
    pipe=Pipeline([('preprocessor',prep),('model',model)])
    pipe.fit(Xtr,ytr); pred=pipe.predict(Xte)
    results.append({'Model':name,'MAE':mean_absolute_error(yte,pred),'RMSE':np.sqrt(mean_squared_error(yte,pred)),'R2':r2_score(yte,pred)})
    if name=='Random Forest': predout['Predicted_Sales']=pred

pd.DataFrame(results).to_csv(out/'model_comparison.csv',index=False)
predout.sort_values('Date').to_csv(out/'sales_forecast_results.csv',index=False)
print(pd.DataFrame(results).to_string(index=False))
