# Retail Sales Forecasting and Business Intelligence Dashboard

## Abstract
This project develops an end-to-end retail analytics and sales forecasting solution using Python, SQL, machine learning and Power BI. Historical transaction data is cleaned and analyzed to identify sales trends, store performance, category performance, product performance and promotion patterns. Regression models are evaluated using MAE, RMSE and R², and prediction results are integrated into an interactive Power BI dashboard.

## 1. Introduction
Retail organizations generate large volumes of transaction data. Converting this data into insights can support inventory, promotion and planning decisions.

## 2. Problem Statement
Develop a data-driven solution to analyze historical retail sales and forecast future sales.

## 3. Objectives
- Clean and analyze retail data.
- Perform SQL business analysis.
- Conduct EDA.
- Engineer machine-learning features.
- Compare forecasting/regression models.
- Generate sales predictions.
- Build a Power BI dashboard.
- Produce actionable business insights.

## 4. Dataset
The project dataset contains 12,000 synthetic retail transactions covering 2024–2025.

## 5. Methodology
Dataset -> Cleaning -> SQL -> EDA -> Feature Engineering -> ML -> Evaluation -> Forecasting -> Power BI.

## 6. Tools
Python, Pandas, NumPy, Matplotlib, Scikit-learn, MySQL and Power BI.

## 7. Results
Insert the actual values from `outputs/model_comparison.csv`.

## 8. Dashboard
Insert screenshots of the completed Power BI dashboard.

## 9. Business Insights
Document the highest-performing stores, categories, products, sales periods and promotion patterns from the actual analysis.

## 10. Limitations
The dataset is synthetic and intended for academic/project demonstration.

## 11. Future Scope
Add holidays, weather, inventory, local events, competitor pricing and advanced time-series models.

## 12. Conclusion
The project demonstrates an end-to-end retail analytics workflow that transforms transaction data into business insights and sales forecasts.
